/*Program that imports a library of 100 books (Titles, Author names and ISBNN codes). Allows user to Check for Availibility of books,
Borrow books and allows Librarians to accept books returned, deciding whether a Fine is warranted or not.*/
#include<iostream>
#include<fstream>
#include<sstream>
#include <limits>
#define N 100
using namespace std;

class B{ //Class that creates a blueprint for parameters of a Book in the Library:
    string n,a; long long int isbn; bool f;
    
    public:
    B(){
        n=a=""; isbn=0; f=1;
    }
    void setn(string n1){ n=n1;} 
    void seta(string a1){ a=a1;}
    void setisbn(long long int is){ isbn=is;}
    void setf(bool f1){ f=f1;}
    string getn(){ return n;}
    string geta(){ return a;}
    long long int getisbn(){ return isbn;}
    bool getf(){ return f;}
};

class L{ //Class Managing various Library Functionalities:
    B a[N];
    int count=0;
    
    public:
    void loadBooks(){ //Initially Loads all the Books in the Library.
        string fn="books.txt"; 
        fstream f; f.open(fn,ios::in);
        if(!f){
            cout<<"\n\nFile: "<<fn<<" NOT Found";
            exit(0);
        }
        string row,n,au; long long int isbn;
        while(getline(f,row)){
            stringstream s(row);
            getline(s,n,',');
            getline(s,au,',');
            s>>isbn;
            a[count].setn(n);
            a[count].seta(au);
            a[count].setisbn(isbn);
            count++;
        }
        
        f.close();
    }
    
    void checkOut(){ //Allows Librarian to Lend out Books to Users.
        while(1){
            cout<<"\nEnter ISBN code of Book to be Lent out: ";
            long long int is; cin >> is;
            bool f=0;
            for(int i=0;i<count;i++){
                if (a[i].getisbn()==is){
                    f=1;
                    if (a[i].getf()==1){
                        cout<<endl<<a[i].getn()<<", by "<<a[i].geta()<<" is Approved to be Borrowed.";
                        a[i].setf(0);
                        return; 
                    } 
                    else{
                        cout<<"\nRequired Book, "<<a[i].getn()<<", by " <<a[i].geta()<<" is Already Borrowed.";
                        cout<<"\n\nIs there any other Book that may interest the Customer? (Enter 'y' for Yes): ";
                        char c; cin >> c;
                        if(c=='y'||c=='Y'){ 
                            checkOut(); return;
                        }
                        else return; 
                    }
                }
            }
            if (f==0){
                cout <<"\nIncorrect ISBN code; Please retry.\n";
            }
        }
    }
    
    void search(){ //Allows Users to Check for the Avalibility of Books.
        cout << "\nSearch Book by Title (Enter 1), or Author (2), or ISBN (3): ";
        char c; cin>>c; cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (!(c==49||c==50||c==51)){
            cout << "\nInvalid Input. Please retry.\n";
            search(); return;
        }
        if (c==49){
            cout<<"\nEnter Book Title: ";
            string n; getline(cin,n);
    
            for (int i = 0;i<count;i++) {
                if (a[i].getn()==n) {
                    if (a[i].getf()==1){
                        cout << "\n"<<a[i].getn()<<", by "<<a[i].geta()<<", is AVAILABLE to Borrow.";
                        return;
                    } 
                    else{
                        cout<<"\nSorry, "<<a[i].getn()<<", by "<<a[i].geta()<<", is Already Borrowed at the moment.\nPlease try again some other time.";
                        return;
                    }
                }
            }
            cout << "\nSorry, "<<n<<", is not included in our Library Collection.";
            return;
        } 
        else if(c==50){
            cout<<"\nEnter Author Name: ";
            string au;
            getline(cin, au);
    
            bool f=0;
            for (int i=0;i<count;i++){
                if(a[i].geta()==au) {
                    if(a[i].getf()==1){
                        cout<<"\n\t"<<a[i].getn()<<", is AVAILABLE to Borrow.";
                        f=1;
                    } 
                    else{
                        cout<<"\n\t"<<a[i].getn()<<", is ALREADY LENT OUT at the moment.";
                        f = 1;
                        
                    }
                }
            }
            if (f == 0) {
                cout << "\nSorry, No works by the Author: " << au << " are part of our Library Collection.";
            }
            return;
        } 
        else {
            cout<<"\nEnter ISBN code: "; long long int is; cin>>is;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  
            for(int i=0;i<count;i++){
                if (a[i].getisbn()==is){
                    if(a[i].getf()==1){
                        cout<<"\n"<<a[i].getn()<<", by "<<a[i].geta()<<", is AVAILABLE to Borrow.";
                        return;
                    } 
                    else{
                        cout<<"\nSorry, "<<a[i].getn()<<", by "<<a[i].geta()<<", is Already Borrowed at the moment.\nPlease try again some other time.";
                        return;
                    }
                }
            }
            cout << "\nSorry, ISBN " << is << ", is not included in our Library Collection.";
            return;
        }
    }

    int fine(int d){ //Calculates a Cumulative Fine, if so warranted. 
        int f;
        if(d>14){
            if(d>21){
                if(d>28){
                    f=(d-28)*10 + 7*5 + 7*2;
                    return f;
                }
                f=(d-21)*5 + 7*2;
                return f;
            }
            f=(d-14)*2;
            return f;
        }
        return -1;
    } 
    
    void rtrn(){ //Allows Library to Accept back Books from Users. 
        cout<<"\nEnter ISBN code of the Book being Returned: "; long long int is; cin>>is; bool f=0;
        for(int i=0;i<count;i++){
            if(a[i].getisbn()==is && a[i].getf()==0){
                f=1; 
                a[i].setf(1); 
                break;
            }
        }
        if(f==0){
            cout<<"\n\nError; Pls retry."; 
            rtrn(); return;
        }
        
        cout<<"\nEnter Borrowed Time length in days: "; int d; cin>>d;
        if(d<0){
            cout<<"\nInvalid input. Pls retry.";
            rtrn(); return;
            
        }
        if(d>14){
            cout<<"\n\nAs the Borrowing Time limit of 2 Weeks has elapsed,\nCustomer will be charged a FINE as per the following:";
            cout<<"\nEvery day post 2 Weeks:\t2 Rs.";
            cout<<"\nEvery day post 3 Weeks:\t5 Rs.";
            cout<<"\nEvery day post 4 Weeks:\t10 Rs.";
            cout<<"\n\tTotal fine: "<<fine(d)<<" Rs.";
            return;
        }
        cout<<"\n\nThank You for returning the Book on time.";
    }

};

int main(){ 
    L l; 
    l.loadBooks();
    cout<<"\n\n\t\tWelcome to LIBRARY MANAGEMENT System\n________________________________________________________________";
    char c;
    while(1){
        cout<<"\n\n\t\tEnter:\n\t1. To Search for Books (Title, Author or ISBN code)\n\t2. Borrow Books\n\t3. Return Books\n\t4. Exit";
        cout<<"\n\nChoice: "; cin>>c;
        switch(c){
            case '1': l.search();
                    break;
            case '2': l.checkOut();
                    break;
            case '3': l.rtrn();
                    break; 
            case '4': cout<<"\n\n______________Thankyou for Visiting. Do come back again._______________"; exit(0);
        }
    }
    
    exit(0);
}