#include <iostream>
#include<ctime>
#include<cstdlib>
using namespace std; 

int main()
{
    srand(time(0));
    int n=rand()%100+1;
    int g=0, a=0, d=0; char c;
    
    cout<<"\n\n\t\t\tNUMBER GUESSING GAME:\n\t\tGuess a Number between 1 and 100"; 
    
    while(a!=n){ 
        cout<<"\n\nEnter your Guess: "; cin>>a; g++;
        if(a<n){
            d=n-a;
            if(d>30) cout<<"\nGuess was quite a lot Lower than the No.\nTry again.";
            else if(d<=5) cout<<"\nVery Close! But the Number is a little Larger.";
            else cout<<"\nGuess was Lower than the No.\nTry again.";
            continue;
        }
        else if(a>n){
            d=a-n;
            if(d>30) cout<<"\nGuess was much Higher than the No.\nTry again.";
            else if(d<=5) cout<<"\nVery Close! But the Number is a little Smaller.";
            else cout<<"\nGuess was Higher than the No.\nTry again.";
            continue;
        }
        else{
            cout<<"\n\t\tYay Correct Guess!\n\t\tIt took you "<<g<<" Gueses.";
            cout<<"\n\nEnter Y to play again: "; cin>>c; 
            if(c=='Y'||c=='y'){
                n=rand()%100+1;
                a=g=d=0; continue;
            }
            cout<<"\n\t\tThanks for Playing.";
            break;
        }
    }
     exit(0);
}