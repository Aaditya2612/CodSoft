/*Program to Implement a To-Do-List by: creating an Array of Objects of the class: T, using another class: Manage, to perform req'd functions.*/

#include <iostream>
using namespace std; 
#define N 100

class T{
    private:
    bool c; string task;
    public:
    T(){
        c=0; task="";
    }
    void sc(bool c1){ c=c1;}
    bool gc(){ return c;}
    void stask(string task1){ task=task1;}
    string gtask(){ return task;}
};

class Manage{
    T a[N];
    public:
    
    int set(){
        cout<<"\n\nEnter no. of Tasks you want to complete today: "; int n; cin>>n; 
        cout<<"\nMention them in an Order:"; string t; cout<<"\n\n";
        for(int i=0; i<n; i++){
            cout<<i+1<<". ";
            cin>>t; a[i].stask(t);
        }
        return n;
    }
    
    void add(int n){
        cout<<"\nEnter Task you wish to Add: "; string t; cin>>t;
        cout<<"\nPosition of the Task in the List: "; int x; cin>>x;
        for(int i=n;i>x-1;i--){
            a[i].stask(a[i-1].gtask());
            a[i].sc(a[i-1].gc());
        }
        a[x-1].stask(t);
        a[x-1].sc(0);
        cout<<"\nTask Added.";
    }
    
    void disp(int n){
        cout<<"\nDisplaying To-Do-List:\n\n";
        for(int i=0;i<n;i++){
            cout<<i+1<<". "<<a[i].gtask()<<"  Status: ";
            if(a[i].gc()==1) cout<<"Completed.";
            else cout<<"Yet to be Completed.";
            cout<<endl;
        }
    }
    
    void mark(int n){
        cout<<"\nEnter no. of Tasks you want to Check as Completed: "; int k,x,l=1; cin>>k;
        while(l<=k){
            cout<<"\nEnter the Task no: "; cin>>x;
            if(x<=0||x>n){
                cout<<"\nInvalid Input. Pls retry."; continue;
            }
            for(int i=0;i<n;i++){
                if(i+1==x){
                    a[i].sc(1); break;
                }
            }
            l++;
        }
        cout<<"\n";
        disp(n);
    }
    
    void markall(int n){
        for(int i=0;i<n;i++){
            a[i].sc(1);
        }
        cout<<"\nCongratulations on Completing All your Tasks!";
        cout<<"\n"; disp(n);
    }
};

int main()
{
    Manage m;
    cout<<"\n\t\tTO DO LIST\n____________________________________________________";
    int n=m.set();
    
    char c='@';
    while(c!='5'){
        cout<<"\n\n\t\tEnter:\n\t1. To Add Tasks.\n\t2. To Mark Specific Tasks as Completed.\n\t3. To Mark ALL Tasks as Completed.\n\t4. Display To Do List.\n\t5. Exit.\n\n";
        cin>>c;
        switch(c){
            case '1': m.add(n); n++;
                     break;
            case '2': m.mark(n); 
                    break;
            case '3': m.markall(n);
                    break;
            case '4': m.disp(n);
                    break;
            case '5': cout<<"\n\t\tThank you for Visiting.\n_________________________Exitting..._____________________________";
                    exit(0);
            default: cout<<"\n\nInvalid Input. Pls retry.";
                    continue;
        }
    }
}